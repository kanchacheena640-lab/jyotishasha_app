import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// Core Widgets Imports
import 'package:jyotishasha_app/core/widgets/greeting_header_widget.dart';
import 'package:jyotishasha_app/core/widgets/horoscope_card_widget.dart';
import 'package:jyotishasha_app/core/widgets/panchang_card_widget.dart';
import 'package:jyotishasha_app/core/widgets/shubh_muhurth_preview_widget.dart';
import 'package:jyotishasha_app/core/widgets/blog_carousel_widget.dart';
import 'package:jyotishasha_app/core/widgets/bottom_nav_bar_widget.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8F6FB),

      // 🔹 Body
      body: SafeArea(
        child: SingleChildScrollView(
          // 👇 replaced CustomScrollView with SingleChildScrollView for visibility
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🟣 Greeting Header
              GreetingHeaderWidget(userName: "Suvi", zodiacSign: "♑ Capricorn"),

              const SizedBox(height: 10),

              // 🟣 Horoscope Section
              Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: Text(
                  "Your Personalized Horoscope",
                  style: GoogleFonts.playfairDisplay(
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF4B0082),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.only(left: 16, bottom: 8),
                child: Row(
                  children: const [
                    HoroscopeCardWidget(
                      title: "Today",
                      summary:
                          "The Moon in your sign boosts your emotions and intuition. Trust your instincts today.",
                      luckyColor: "Lavender",
                      luckyNumber: "7",
                    ),
                    HoroscopeCardWidget(
                      title: "Tomorrow",
                      summary:
                          "You may feel introspective; take a moment to reflect and plan your week wisely.",
                      luckyColor: "Silver",
                      luckyNumber: "4",
                    ),
                  ],
                ),
              ),

              // 🟣 Panchang Section
              PanchangCardWidget(
                tithi: "Dwitiya",
                nakshatra: "Rohini",
                sunrise: "06:27 AM",
                sunset: "05:43 PM",
                onViewFull: () {
                  Navigator.pushNamed(context, '/panchang');
                },
              ),

              // 🟣 Shubh Muhurth Section
              ShubhMuhurthPreviewWidget(
                muhurthList: [
                  {"date": "Nov 5", "event": "Griha Pravesh", "score": "9"},
                  {"date": "Nov 8", "event": "Marriage", "score": "8"},
                  {"date": "Nov 12", "event": "Vehicle Purchase", "score": "8"},
                  {"date": "Nov 15", "event": "Naamkaran", "score": "7"},
                ],
                onSeeMore: () {
                  Navigator.pushNamed(context, '/muhurth');
                },
              ),

              // 🟣 Blog Carousel Section
              BlogCarouselWidget(
                blogs: [
                  {
                    "title": "Full Moon in Aries — How it Affects You",
                    "tag": "Lunar Insights",
                    "image":
                        "https://images.unsplash.com/photo-1506744038136-46273834b3fb",
                  },
                  {
                    "title": "Mercury Retrograde Survival Guide",
                    "tag": "Planetary Transit",
                    "image":
                        "https://images.unsplash.com/photo-1523983306281-4b570fba04c4",
                  },
                ],
                onExplore: () {
                  Navigator.pushNamed(context, '/blogs');
                },
              ),

              const SizedBox(height: 30),
            ],
          ),
        ),
      ),

      // 🔹 Bottom Navigation
      bottomNavigationBar: BottomNavBarWidget(
        currentIndex: _currentIndex,
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
          // TODO: Add navigation logic later
        },
      ),
    );
  }
}
