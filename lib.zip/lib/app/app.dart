import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:jyotishasha_app/core/state/language_provider.dart';
import 'package:jyotishasha_app/app/routes/app_routes.dart';
import 'package:jyotishasha_app/app/theme/app_theme.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:jyotishasha_app/core/utils/global_context.dart';

// ⭐ IMPORT THIS
import 'package:jyotishasha_app/l10n/app_localizations.dart';

class JyotishashaApp extends StatelessWidget {
  const JyotishashaApp({super.key});

  @override
  Widget build(BuildContext context) {
    final lang = context.watch<LanguageProvider>().currentLang;

    globalKundaliContext = context;

    return MaterialApp.router(
      title: 'Jyotishasha',
      debugShowCheckedModeBanner: false,

      theme: AppTheme.lightTheme,
      themeMode: ThemeMode.light,

      // ⭐ APPLY LANGUAGE
      locale: Locale(lang),
      supportedLocales: AppLocalizations.supportedLocales,

      // ⭐ MUST HAVE DELEGATES
      localizationsDelegates: const [
        AppLocalizations.delegate, // ← MISSING
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],

      routerConfig: appRouter,
    );
  }
}
