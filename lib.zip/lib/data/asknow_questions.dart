// 📁 lib/data/asknow_questions.dart

final Map<String, List<String>> askNowQuestions = {
  'Love': [
    'Will I marry my current partner?',
    'Does my crush like me?',
    'Is there a new relationship coming soon?',
  ],
  'Career': [
    'Will I get a promotion soon?',
    'Should I change my job?',
    'Will my career grow abroad?',
  ],
  'Finance': [
    'How will my financial status be this month?',
    'Should I invest now?',
  ],
  // 👇 baaki categories yahan add karte jaoge
};
