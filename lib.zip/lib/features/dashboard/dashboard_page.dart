import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:jyotishasha_app/core/constants/app_colors.dart';
import 'package:provider/provider.dart';
import 'package:jyotishasha_app/core/state/kundali_provider.dart';

// 🔹 Import feature pages
import '../astrology/astrology_page.dart';
import '../reports/pages/report_catalog_page.dart';
import '../profile/profile_page.dart';
import 'dashboard_home_section.dart';
import '../asknow/asknow_chat_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _currentIndex = 0;
  DateTime? _lastPressed;

  @override
  void initState() {
    super.initState();

    // 🔹 Load kundali from active profile on dashboard open
    Future.microtask(() {
      if (mounted) {
        context.read<KundaliProvider>().loadFromActiveProfile();
      }
    });
  }

  // ✅ Main tabs
  final List<Widget> _pages = const [
    DashboardHomeSection(),
    AstrologyPage(),
    ReportCatalogPage(),
    AskNowChatPage(),
    ProfilePage(),
  ];

  Future<void> _handleBackPress() async {
    final now = DateTime.now();

    // 🔹 Step 1: If not on Home tab → Go Home
    if (_currentIndex != 0) {
      setState(() => _currentIndex = 0);
      return;
    }

    // 🔹 Step 2: Double back press to minimize (not exit)
    if (_lastPressed == null ||
        now.difference(_lastPressed!) > const Duration(seconds: 2)) {
      _lastPressed = now;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Press back again to minimize app"),
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    // 🔹 Step 3: Gracefully minimize app (avoid black screen)
    await Future.delayed(const Duration(milliseconds: 150));
    SystemNavigator.pop(); // ✅ Proper minimize, no hang or black flash
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) {
        if (didPop) return;
        _handleBackPress();
      },
      child: Scaffold(
        backgroundColor: theme.scaffoldBackgroundColor,

        // 🔹 Page Content
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          child: _pages[_currentIndex],
        ),

        // 🔹 Bottom Navigation Bar
        bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) => setState(() => _currentIndex = index),
          selectedItemColor: theme.colorScheme.primary,
          unselectedItemColor: AppColors.textPrimary.withValues(alpha: 0.5),
          backgroundColor: AppColors.surface,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w600,
          ),
          unselectedLabelStyle: theme.textTheme.bodyMedium?.copyWith(
            fontWeight: FontWeight.w400,
          ),

          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.star_border),
              activeIcon: Icon(Icons.star),
              label: "Astrology",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.description_outlined),
              activeIcon: Icon(Icons.description),
              label: "Reports",
            ),
            BottomNavigationBarItem(
              icon: _AskNowIcon(),
              activeIcon: Icon(Icons.chat),
              label: "Ask Now",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: "Profile",
            ),
          ],
        ),
      ),
    );
  }
}

/// ✅ Separated custom Ask Now icon widget for clarity
class _AskNowIcon extends StatelessWidget {
  const _AskNowIcon();

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        const Icon(Icons.chat_bubble_outline),
        Positioned(
          right: -10,
          top: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.circular(6),
            ),
            child: const Text(
              "FREE",
              style: TextStyle(
                color: Colors.white,
                fontSize: 8,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
      ],
    );
  }
}
