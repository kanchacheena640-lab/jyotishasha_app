import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ShubhMuhurthPreviewWidget extends StatelessWidget {
  final List<Map<String, String>> muhurthList;
  final VoidCallback? onSeeMore;

  const ShubhMuhurthPreviewWidget({
    super.key,
    required this.muhurthList,
    this.onSeeMore,
  });

  String _getEmoji(String event) {
    event = event.toLowerCase();
    if (event.contains('marriage')) return '💍';
    if (event.contains('griha')) return '🏠';
    if (event.contains('vehicle')) return '🚗';
    if (event.contains('naam') || event.contains('naming')) return '👶';
    return '🌸';
  }

  @override
  Widget build(BuildContext context) {
    // 🌈 Jyotishasha Gradient for Heading Text
    const jyotishashaGradient = LinearGradient(
      colors: [Color(0xFFFF9933), Color(0xFF8E2DE2)],
      begin: Alignment.centerLeft,
      end: Alignment.centerRight,
    );

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // 🔹 Centered Gradient Heading
          ShaderMask(
            shaderCallback: (bounds) => jyotishashaGradient.createShader(
              Rect.fromLTWH(0, 0, bounds.width, bounds.height),
            ),
            child: Text(
              "Upcoming Shubh Muhurth",
              textAlign: TextAlign.center,
              style: GoogleFonts.playfairDisplay(
                textStyle: const TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white, // placeholder for gradient
                ),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // 🔹 Horizontal Cards (smaller boxes)
          SizedBox(
            height: 110, // reduced height
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: muhurthList.length,
              itemBuilder: (context, index) {
                final item = muhurthList[index];
                final emoji = _getEmoji(item['event'] ?? '');

                return Container(
                  width: 145, // reduced width
                  margin: const EdgeInsets.only(right: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    // 🌸 Lavender–bluish gradient like greeting section
                    gradient: const LinearGradient(
                      colors: [Color(0xFFEDE7FF), Color(0xFFD6CCFF)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(16),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        offset: Offset(1, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "$emoji  ${item['date'] ?? ''}",
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF3A0CA3),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        item['event'] ?? '',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF240046),
                        ),
                      ),
                      const Spacer(),
                      Row(
                        children: [
                          const Icon(Icons.star, size: 14, color: Colors.amber),
                          const SizedBox(width: 4),
                          Text(
                            "${item['score'] ?? ''}/10",
                            style: const TextStyle(
                              fontSize: 12,
                              color: Color(0xFF3C096C),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 16),

          // 🔹 "See More" below cards, slightly bigger font
          GestureDetector(
            onTap: onSeeMore,
            child: Text(
              "See More →",
              style: GoogleFonts.montserrat(
                textStyle: const TextStyle(
                  fontSize: 15,
                  color: Color(0xFF5A189A),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
