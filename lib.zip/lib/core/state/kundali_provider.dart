import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:jyotishasha_app/core/models/kundali_model.dart';

class KundaliProvider extends ChangeNotifier {
  KundaliModel? kundali;
  Map<String, dynamic>? kundaliData; // 🌕 Full Kundali JSON cache
  bool isLoading = false;
  String? errorMessage;

  /// 🌐 Fetch Kundali from backend and return parsed data
  Future<Map<String, dynamic>?> fetchKundali({
    required String name,
    required String dob,
    required String tob,
    required String pob,
    required double lat,
    required double lng,
    String language = "en",
  }) async {
    try {
      isLoading = true;
      errorMessage = null;
      notifyListeners();

      final url = Uri.parse(
        'https://jyotishasha-backend.onrender.com/api/full-kundali-modern',
      );

      final payload = {
        "name": name,
        "dob": dob,
        "tob": tob,
        "place_name": pob,
        "lat": lat,
        "lng": lng,
        "timezone": "+05:30",
        "language": language,
        "ayanamsa": "Lahiri",
      };

      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(payload),
      );

      if (response.statusCode == 200) {
        kundali = KundaliModel.fromRawJson(response.body);
        kundaliData = jsonDecode(response.body);
        return kundaliData;
      } else {
        errorMessage = "Failed (Status ${response.statusCode})";
        return null;
      }
    } catch (e) {
      errorMessage = "Error: $e";
      return null;
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// 🔹 Load Kundali directly from Firestore active profile
  Future<void> loadFromActiveProfile() async {
    try {
      isLoading = true;
      notifyListeners();

      final user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        errorMessage = "No user logged in";
        return;
      }

      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get();
      final activeProfileId = userDoc.data()?['activeProfileId'];

      if (activeProfileId == null) {
        errorMessage = "No active profile found";
        return;
      }

      final profileSnap = await FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .collection('profiles')
          .doc(activeProfileId)
          .get();

      if (!profileSnap.exists) {
        errorMessage = "Profile not found";
        return;
      }

      final profile = profileSnap.data()!;
      await fetchKundali(
        name: profile['name'] ?? '',
        dob: profile['dob'] ?? '',
        tob: profile['tob'] ?? '',
        pob: profile['pob'] ?? '',
        lat: (profile['lat'] ?? 26.8467).toDouble(),
        lng: (profile['lng'] ?? 80.9462).toDouble(),
        language: (profile['language'] ?? 'English')
            .toString()
            .toLowerCase()
            .substring(0, 2),
      );
    } catch (e) {
      errorMessage = "Error loading profile: $e";
    } finally {
      isLoading = false;
      notifyListeners();
    }
  }

  /// 🧩 Build consistent payload
  Map<String, dynamic> buildKundaliPayload(Map<String, dynamic> source) {
    return {
      "name": source["name"] ?? "",
      "dob": source["dob"] ?? "",
      "tob": source["tob"] ?? "",
      "place_name": source["pob"] ?? "",
      "lat": source["lat"] ?? 26.8467,
      "lng": source["lng"] ?? 80.9462,
      "timezone": "+05:30",
      "language": source["language"] ?? "en",
      "ayanamsa": "Lahiri",
    };
  }

  /// 🔁 Clear stored Kundali
  void clearKundali() {
    kundali = null;
    kundaliData = null;
    errorMessage = null;
    notifyListeners();
  }
}
