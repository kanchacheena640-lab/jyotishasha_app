import 'package:flutter/material.dart';

class AppColors {
  // 🌙 Brand Palette (From Next.js Tailwind)
  static const Color primary = Color(0xFF6B21A8); // Purple
  static const Color secondary = Color(0xFF4C1D95); // Indigo shade
  static const Color accent = Color(0xFF2563EB); // Blue button
  static const Color accentDark = Color(0xFF1D4ED8); // Hover blue
  static const Color surface = Colors.white; // Card background

  // 🪔 Gradients (Next.js bg-gradient-to-b from-[#0f0c29] via-[#302b63] to-[#24243e])
  static const Color backgroundStart = Color(0xFF0F0C29);
  static const Color backgroundMid = Color(0xFF302B63);
  static const Color backgroundEnd = Color(0xFF24243E);

  // ✨ Text Colors
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Colors.white70;

  // 🌈 Reusable gradients
  static const LinearGradient darkBackgroundGradient = LinearGradient(
    colors: [backgroundStart, backgroundMid, backgroundEnd],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient purpleGradient = LinearGradient(
    colors: [secondary, primary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient gradientBlue = LinearGradient(
    colors: [Color(0xFFDBEAFE), Color(0xFFE0E7FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
